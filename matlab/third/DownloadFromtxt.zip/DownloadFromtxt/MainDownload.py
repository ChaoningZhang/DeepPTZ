from urllib2 import urlopen
import urllib

#uurl = 'http://sun360.csail.mit.edu/Images/SUN360_urls_9104x4552/others.txt'

#def download(t_url):
#    response = urlopen(t_url)
#    data = response.read()
#    txt_str = str(data)
#    lines = txt_str.split("\\n")
#    des_url = './others.txt'
#    fx = open(des_url,"w")
#    for line in lines:
#        fx.write(line+ "\n")
#    fx.close()

#download(uurl)
DOWNLOADS_DIR = './'

# For every line in the file
for url in open('others.txt'):
    # Split on the rightmost / and take everything on the right side of that
    name = url.rsplit('/', 1)[-1]

    # Combine the name and the downloads directory to get the local filename
    filename = os.path.join(DOWNLOADS_DIR, name)

    # Download the file if it does not exist
    if not os.path.isfile(filename):
        urllib.urlretrieve(url, filename)
